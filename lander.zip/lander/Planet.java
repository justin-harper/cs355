//Justin Harper
//WSUID 10696738

package lander;

public class Planet 
{

    private double gravity; /* units: (m/s/s) */
    private double ground;  /* units: m */
    private String name;
       
    public Planet() 
    {
        gravity = 1;
        ground = 0;
        name = "Sihtkcuf";
    }
    
    public String getName()
    {
        return name;
    }
    
    public double getGravity()
    {
        return gravity;
    }
    
    public double getGround()
    {
        return ground;
    }
    
}