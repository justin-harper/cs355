//Justin Harper
//WSUID 10696738
package lander;
import java.io.*;
import java.util.Scanner;

class Game
{
    private static final double noBurn = 0.0;

    private static final double fullBurn = 1.0;

    private static final double deltaTime = 0.5;

    private static void play(Rocket rocket) throws RocketException
    {
        while (true) 
        {
            /* read input and decide whether to burn or not */
            //   Scanner reader = new Scanner(System.in);
            //   String input = reader.next();
            
            BufferedReader buf = new BufferedReader (new InputStreamReader (System.in));

            String input = "";
            try
            {
                 input = buf.readLine();
            }
            catch (Exception e)
            {
                
            }
 
            if(input.equals("b"))
            {
                //burn
                rocket.move(deltaTime, fullBurn); 
                System.out.println(rocket.getHeightString());
            }
            if(input.isEmpty())
            {
                //coast
                rocket.move(deltaTime, noBurn);
                System.out.println(rocket.getHeightString());
            }
        }
    }

    public static void main(String[] args) 
    {
        /* create a planet with gravity 0.3 and surface at 0.0 */
        //Planet pluto = new Planet();
        /* create a rocket with engine strength 2.0, 20.0 units of fuel */
        Rocket rocket = new Rocket(2.0, 20.0, new Planet());
        rocket.setHeight(50.0);

        try 
        {
            play(rocket);
        } 
        catch (RocketException v) 
        {
            System.out.println(v.getMessage());
        }
    }

}
