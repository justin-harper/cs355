//Justin Harper
//WSUID 10696738
package lander;


import java.text.DecimalFormat;

class Rocket
 {
    static final RocketException crashed = new RocketException("Crashed and Burned");
    static final RocketException landed = new RocketException("Safely Landed");

    private double velocity = 0.0; // default to 0
    private double height = 50.0; // default to 50.0
    
    private Planet planet;

    private static final double safeVelocity = -1.0; // Land within this
                                                       // velocity
    private double engineStrength;
    private double fuel;
   
    public Rocket(double myStrength, double myFuel, Planet newPlanet)
    {
        engineStrength = myStrength;
        fuel = myFuel;
        planet = newPlanet;
    }
    
    public double getHeight()
    {
        return height;
    }
    
    public double getVelocity()
    {
        return velocity;
    }
    
    public void setHeight(double h)
    {
        height = h;
    }
    
    public String getState()
    {
        DecimalFormat df = new DecimalFormat(" ###.##");
        return "Height: "+df.format(height)+" | Velocity: "+df.format(velocity)+" | Fuel: "+df.format(fuel);
    }
    
    private void nextHeight(double deltaTime) throws RocketException
    {
        height += (velocity * deltaTime);

        if (reachedSurface()) 
        {
            if (velocity < safeVelocity) 
            {
                throw crashed;
            } 
            else 
            {
                throw landed;
            }
        }
    }

    private boolean reachedSurface() 
    {
        /* true if rocket is at or below the planet's surface */
        if(height <= planet.getGround())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    private boolean landed()
    {
        if(reachedSurface() && velocity >= safeVelocity)
        {
            return true;            
        }

        return false;
    }

    private void nextVelocity(double burnRate, double deltaTime) 
    {
        velocity += (((engineStrength * burnRate) - planet.getGravity()) * deltaTime);
    }
    
    public void nextFuel(double burnRate, double deltaTime)
    {
        fuel -= (burnRate*deltaTime);
    }

    public void move(double dt, double burnRate) throws RocketException
    {
        /* note that dt is measured in seconds */
        if (!reachedSurface()) 
        {
            /*  update the height, velocity and fuel             
                fuel check. If not enough fuel for full burnrate, adjust burnrate to use up remaining fuel exactly in dt time.
            */
            double fuelNeeded = burnRate * dt;

            if(fuel < fuelNeeded)
            {
                burnRate = fuel; 
            }
            else 
            {
                //then we need to subtract the fuel needed for the burn
                fuel -= fuelNeeded;
            }
            
            //burn and update velocity, then 
            nextVelocity(burnRate, dt);
            nextHeight(dt);           
        }
    }

    public String getHeightString() 
    {
        double maxHeight = (height > 60.0) ? height : 60.0;
        double belowGround = planet.getGround() - 10.0;

        int size = (int) (maxHeight - belowGround) + 1;

        char[] buffer = new char[size];

        DecimalFormat df = new DecimalFormat(" ###.##");

        int groundPosition = (int) (planet.getGround() - belowGround);

        for (int i = 0; i < size; i++)
        {
            buffer[i] = ' ';
        }

        int adjustedPosition = (int) (height - belowGround);
        adjustedPosition = (adjustedPosition <= 0) ? 0 : adjustedPosition;
        buffer[groundPosition] = '|';
        buffer[adjustedPosition] = '*';
        return (new String(buffer) + " " + df.format(velocity));
    }
}
